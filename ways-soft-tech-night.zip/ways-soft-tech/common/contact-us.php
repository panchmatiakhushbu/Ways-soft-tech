<section class="contact_us pad-80" id="contactus">
  <div class="container">
    <div class="contact_inner">
      <div class="row">
        <div class="col-lg-9 col-md-12">
          <div class="contact_form_inner">
            <div class="contact_field">
              <h3>Contatc Us</h3>
              <p>Feel Free to contact us any time. We will get back to you as soon as we can!.</p>
              <input type="text" class="form-control form-group" placeholder="Name" />
              <input type="text" class="form-control form-group" placeholder="Email" />
              <textarea class="form-control form-group" placeholder="Message"></textarea>
              <a class="custom-btn mt-4">Submit</a>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-12">
          <div class="right_conatct_social_icon d-flex align-items-end">
            <div class="socil_item_inner d-flex">
              <li>
                <a href="#">
                  <i class="bi bi-linkedin"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="bi bi-instagram"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="bi bi-twitter"></i>
                </a>
              </li>
            </div>
          </div>
        </div>
      </div>
      <div class="contact_info_sec">
        <h4>Contact Info</h4>
        <div class="d-flex info_single align-items-baseline">
          <i class="bi bi-headset"></i>
          <span>
            <a href="tel:9925028058" class="text-white text-decoration-none">+91 9925028058</a>
          </span>
        </div>
        <div class="d-flex info_single align-items-baseline">
          <i class="bi bi-envelope-open"></i>
          <span>
            <a href="mailto:vmehta@wayssoftware.com" class="text-white text-decoration-none">vmehta@wayssoftware.com</a>
          </span>
        </div>
        <div class="d-flex info_single align-items-baseline">
          <i class="bi bi-geo-alt"></i>
          <span>WAYS SOFTWARE TECHNOLOGIES LLP <br> B 904, Decora 9 Square, <br> Near Marwadi Building, <br> Near Nana Mova Circle, <br> RAJKOT - 360 005 <br> Gujarat - INDIA </span>
        </div>
      </div>
    </div>
  </div>
</section>