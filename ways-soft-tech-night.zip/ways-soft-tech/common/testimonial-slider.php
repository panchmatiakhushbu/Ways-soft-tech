<section class="testimonial_section">
  <div class="container">
    <div class="row">
      <div class="col-lg-7">
        <div class="about_content">
          <div class="background_layer"></div>
          <div class="layer_content">
            <div class="section_title">
              <h5>Testimonials</h5>
              <h2>Happy with <strong>Customers & Clients</strong>
              </h2>
              <div class="heading_line">
                <span></span>
              </div>
              <p>We always keep technology closer to our hearts and solve customer's problems faster and better.</p>
              <p>We are here to solve the problems of businesses. We empower startups and entrepreneurs with the best technologies to help them convert their ideas into reality that revolutionizes industries.</p>
            </div>
            <a href="#contactus">Contact Us</a>
          </div>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="testimonial_box">
          <div class="testimonial_container">
            <div class="background_layer"></div>
            <div class="layer_content">
              <div class="testimonial_owlCarousel owl-carousel">
                <div class="testimonials">
                  <div class="testimonial_content">
                    <div class="testimonial_caption">
                      <h6>Brandon Ferguson</h6>
                      <span>Chicago, USA</span>
                    </div>
                    <p>We have been working with Ways Soft-Tech for more than two years. They have played a significant part in building different platforms. They have some of the finest developers we have worked with, and we have enjoyed dealing with them. Thanks a lot for everything.</p>
                  </div>
                  <div class="images_box">
                    <div class="testimonial_img">
                      <img class="img-center" src="images/user-1.jpg" alt="Client">
                    </div>
                  </div>
                </div>
                <div class="testimonials">
                  <div class="testimonial_content">
                    <div class="testimonial_caption">
                      <h6>James Wilson</h6>
                      <span>London, UK</span>
                    </div>
                    <p>Ways Soft-Tech has been greatly involved in our successful business journey. With their help, we have climbed from nearly zero to a well-made eight figures valuation in roughly one year.</p>
                  </div>
                  <div class="images_box">
                    <div class="testimonial_img">
                      <img class="img-center" src="images/user-2.jpg" alt="Client">
                    </div>
                  </div>
                </div>
                <div class="testimonials">
                  <div class="testimonial_content">
                    <div class="testimonial_caption">
                      <h6>Paul Schneider</h6>
                      <span>Germany</span>
                    </div>
                    <p>The team of Ways Soft-Tech has been elementary in dealing with all the cutting-edge technologies and application development. They have beat out all the service providers we have evaluated by miles in their capability to deliver the best. Their objective is to work for startups like a highly professional organization would work for a business corporation.</p>
                  </div>
                  <div class="images_box">
                    <div class="testimonial_img">
                      <img class="img-center" src="images/user-4.jpg" alt="Client">
                    </div>
                  </div>
                </div>
                <div class="testimonials">
                  <div class="testimonial_content">
                    <div class="testimonial_caption">
                      <h6>Adil Rasheed</h6>
                      <span>UAE</span>
                    </div>
                    <p>The work quality, communication, and care about details given to our company by the Ways Soft-tech team was invaluable. Their attention to even smaller details and real interest in helping us succeed were important factors to help us make a dedicated and caring business relationship, which promises to get more opportunities from this association in the future.</p>
                  </div>
                  <div class="images_box">
                    <div class="testimonial_img">
                      <img class="img-center" src="images/user-3.jpg" alt="Client">
                    </div>
                  </div>
                </div>
                <div class="testimonials">
                  <div class="testimonial_content">
                    <div class="testimonial_caption">
                      <h6>Brady Johnson</h6>
                      <span>New Zealand</span>
                    </div>
                    <p>We have been dealing with Ways Soft-Tech for the last three years. They played a significant part in creating different platforms for us. The company is probably the best we have worked with, and we enjoyed working with them.</p>
                  </div>
                  <div class="images_box">
                    <div class="testimonial_img">
                      <img class="img-center" src="images/user-5.jpg" alt="Client">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>