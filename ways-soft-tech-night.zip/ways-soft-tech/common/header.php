<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="icon" type="image/x-icon" href="images/fav-icons.svg">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="google-site-verification" content="aAjmIEIak3X6tIkKtYYCrcYmz7ZKJxNGwKlSVMN8Lew" />
    <meta name="yandex-verification" content="070b673b93a4dba5" />    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/slick.css" rel="stylesheet">
    <link href="css/slick-theme.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <link href="css/owl.theme.default.css" rel="stylesheet">
    <link href="css/aos.css" rel="stylesheet">    
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link href="css/style.css" rel="stylesheet">
  </head>
  <body>
    <header class="navbar">
      <a href="index.php" class="logo main-logo">
        <img src="images/white-logo.svg" alt="logo" width="150" class="img-fluid">
      </a>
      <a href="index.php" class="logo sticky-logo">
        <img src="images/logo.svg" alt="logo" width="130" class="img-fluid">
      </a>
      <div class="menu-btn">
        <div class="menu-btn__lines"></div>
      </div>
      <ul class="menu-items">
        <li>
          <a href="index.php" class="menu-item first-item">Home</a>
        </li>
        <li class="dropdown">
          <a href="javascript:void(0);" class="menu-item first-item expand-btn">Our Delivery Apps </a>
          <ul class="dropdown-menu sample">
            <li>
              <a href="#" class="menu-item">Food Delivery App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Grocery Delivery App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Medicine Delivery App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Multi-Delivery App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Pizza Delivery App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Liquor Delivery App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Meat Delivery App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Pharmacy Delivery App</a>
            </li>
            <!--<li class="dropdown dropdown-right"><a href="#" class="menu-item expand-btn">
            Item 4
          </a><ul class="menu-right sample"><li><a href="#" class="menu-item">Item 4.1</a></li><li><a href="#" class="menu-item">Item 4.2</a></li><li><a href="#" class="menu-item">Item 4.3</a></li><li><a href="#" class="menu-item">Item 4.4</a></li><li><a href="#" class="menu-item">Item 4.5</a></li><li><a href="#" class="menu-item">Item 4.6</a></li><li><a href="#" class="menu-item">Item 4.7</a></li><li><a href="#" class="menu-item">Item 4.8</a></li></ul></li>-->
          </ul>
        </li>
        <li class="dropdown">
          <a href="javascript:void(0);" class="menu-item first-item expand-btn">On Demand Solutions</a>
          <ul class="dropdown-menu sample">
            <li>
              <a href="#" class="menu-item">On Demand Doctor App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Taxi Booking App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Transportation App</a>
            </li>
            <li>
              <a href="#" class="menu-item">On Demand App Development</a>
            </li>
            <li>
              <a href="#" class="menu-item">Electric Vehicle Charging</a>
            </li>
            <li>
              <a href="#" class="menu-item">Photo Editing App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Video Editing App</a>
            </li>
            <li>
              <a href="#" class="menu-item">E-Commerce App Development</a>
            </li>
            <li>
              <a href="#" class="menu-item">Dating App Development</a>
            </li>
            <li>
              <a href="#" class="menu-item">Doctor Appointment Booking App</a>
            </li>
            <li>
              <a href="#" class="menu-item">Food Delivery Solutions</a>
            </li>
            <li>
              <a href="#" class="menu-item">Grocery Delivery Solutions</a>
            </li>
            <!--<li class="dropdown dropdown-right"><a href="#" class="menu-item expand-btn">
            Item 4
          </a><ul class="menu-right menu-left sample"><li><a href="#" class="menu-item">Item 4.1</a></li><li><a href="#" class="menu-item">Item 4.2</a></li><li><a href="#" class="menu-item">Item 4.3</a></li><li><a href="#" class="menu-item">Item 4.4</a></li><li><a href="#" class="menu-item">Item 4.5</a></li><li><a href="#" class="menu-item">Item 4.6</a></li><li><a href="#" class="menu-item">Item 4.7</a></li><li><a href="#" class="menu-item">Item 4.8</a></li></ul></li>-->
          </ul>
        </li>
        <li>
          <a href="javascript:void(0);" class="menu-item first-item expand-btn">Our Services</a>
          <div class="mega-menu sample">
            <div class="content">
              <div class="col">
                <section>
                  <div class="menu-title">Our Services</div>
                  <a href="services.php" class="img-wrapper">
                    <span class="img">
                      <img src="images/menu-service.jpg" alt="Service" class="img-fluid" />
                    </span>
                  </a>
                </section>
              </div>
              <div class="col">
                <section>
                  <div class="menu-title">Mobile Apps Development</div>
                  <ul class="mega-links col-count">
                    <li>
                      <a href="#" class="menu-item">Mobile</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">IOS</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Android</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Bots</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Wearable</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Hybrid</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">React</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">IPad</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Ibeacon</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Flutter</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">IoT</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Swift</a>
                    </li>
                  </ul>
                </section>
              </div>
              <div class="col">
                <section>
                  <div class="menu-title">Website Development</div>
                  <ul class="mega-links">
                    <li>
                      <a href="#" class="menu-item">Website</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">PHP</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Laravel</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Angular</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">NodeJS</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Wordpress</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Cake PHP</a>
                    </li>
                  </ul>
                </section>
              </div>
              <div class="col">
                <section>
                  <div class="menu-title">Other Services</div>
                  <ul class="mega-links">
                    <li>
                      <a href="#" class="menu-item">MVP Development</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Extended Remote Team</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Enterprise Solution Development</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Hire Dedicated Development Team</a>
                    </li>
                  </ul>
                </section>
              </div>
            </div>
          </div>
        </li>
        <li>
          <a href="javascript:void(0);" class="menu-item first-item expand-btn"> Hire Developer</a>
          <div class="mega-menu sample">
            <div class="content three-cols">
              <div class="col">
                <section>
                  <div class="menu-title">Hire Developer</div>
                  <a href="#" class="img-wrapper">
                    <span class="img">
                      <img src="images/hire-now.jpg" alt="Hire Developer" class="img-fluid" />
                    </span>
                  </a>
                </section>
              </div>
              <div class="col">
                <section>
                  <div class="menu-title">Website Developers</div>
                  <ul class="mega-links col-count">
                    <li>
                      <a href="#" class="menu-item">Node Js Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">AWS Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Laravel Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">PHP Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">WordPress Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Web Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">VueJs Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">React JS Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Full Stack Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Shopify Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Woocommerce Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">JavaScript Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Angular JS Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Python Developers</a>
                    </li>
                  </ul>
                </section>
              </div>
              <div class="col">
                <section>
                  <div class="menu-title">Mobile App Developers</div>
                  <ul class="mega-links">
                    <li>
                      <a href="mobileappdevelopment.php" class="menu-item">Mobile App Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">IOS Developers</a>
                    </li>
                    <li>
                      <a href="androidappdevelopment.php" class="menu-item">Android Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">React Native Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Swift Developers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">Flutter Developers</a>
                    </li>
                  </ul>
                  <div class="menu-title">Other</div>
                  <ul class="mega-links">
                    <li>
                      <a href="#" class="menu-item">UI/UX Designers</a>
                    </li>
                    <li>
                      <a href="#" class="menu-item">QA Engineers</a>
                    </li>
                  </ul>
                </section>
              </div>
              <!--<div class="col"><section><div class="menu-title">Other</div><ul class="mega-links"><li><a href="#" class="menu-item">UI/UX Designers</a></li><li><a href="#" class="menu-item">QA Engineers</a></li></ul></section></div>-->
            </div>
          </div>
        </li>
        <li>
          <a href="#" class="menu-item first-item expand-btn">Blog</a>
          <div class="mega-menu blog sample">
            <div class="content">
              <div class="col">
                <a href="#" class="img-wrapper">
                  <span class="img">
                    <img src="https://picsum.photos/400?random=2" alt="Random Image" class="img-fluid" />
                  </span>
                </a>
                <div class="menu-title">Your Title</div>
                <p> I looked at a lot of menus, something is wrong everywhere. In this menu, in my opinion, I took into account all the shortcomings. Simple and clear code in pure JS. No Jquery, Bootstrap and other libraries are closed when you click outside the area and press Esc. </p>
                <a href="#" class="read-more">read more</a>
              </div>
              <div class="col">
                <a href="#" class="img-wrapper">
                  <span class="img">
                    <img src="https://picsum.photos/400?random=3" alt="Random Image" class="img-fluid" />
                  </span>
                </a>
                <div class="menu-title">Your Title</div>
                <p> I looked at a lot of menus, something is wrong everywhere. In this menu, in my opinion, I took into account all the shortcomings. Simple and clear code in pure JS. No Jquery, Bootstrap and other libraries are closed when you click outside the area and press Esc. </p>
                <a href="#" class="read-more">read more</a>
              </div>
              <div class="col">
                <a href="#" class="img-wrapper">
                  <span class="img">
                    <img src="https://picsum.photos/400?random=4" alt="Random Image" class="img-fluid" />
                  </span>
                </a>
                <div class="menu-title">Your Title</div>
                <p> I looked at a lot of menus, something is wrong everywhere. In this menu, in my opinion, I took into account all the shortcomings. Simple and clear code in pure JS. No Jquery, Bootstrap and other libraries are closed when you click outside the area and press Esc. </p>
                <a href="#" class="read-more">read more</a>
              </div>
              <div class="col">
                <a href="#" class="img-wrapper">
                  <span class="img">
                    <img src="https://picsum.photos/400?random=5" alt="Random Image" class="img-fluid" />
                  </span>
                </a>
                <div class="menu-title">Your Title</div>
                <p> I looked at a lot of menus, something is wrong everywhere. In this menu, in my opinion, I took into account all the shortcomings. Simple and clear code in pure JS. No Jquery, Bootstrap and other libraries are closed when you click outside the area and press Esc. </p>
                <a href="#" class="read-more">read more</a>
              </div>
            </div>
          </div>
        </li>
        <li class="dropdown">
          <a href="javascript:void(0);" class="menu-item first-item expand-btn">About Us</a>
          <ul class="dropdown-menu sample">
            <li>
              <a href="about.php" class="menu-item">About Us</a>
            </li>
            <li>
              <a href="services.php" class="menu-item">Our services</a>
            </li>
            <li>
              <a href="#" class="menu-item">Testimonials</a>
            </li>
            <li>
              <a href="#" class="menu-item">Engagement Model</a>
            </li>
            <li>
              <a href="#" class="menu-item">Become A Partner</a>
            </li>
            <li>
              <a href="#" class="menu-item">Blog</a>
            </li>
            <li>
              <a href="#" class="menu-item">Life At Ways</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="#" class="menu-item first-item">Career</a>
        </li>
        <li>
          <a href="#" class="menu-item first-item">Our Work</a>
        </li>
        <li>
          <a href="contactus.php" class="menu-item first-item">Contact Us</a>
        </li>
      </ul>
    </header>