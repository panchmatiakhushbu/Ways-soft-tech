<footer class="pad-80">
  <div class="container">
    <div class="row">
      <div class="col-lg-2 col-md-4">
        <h5>
          <a href="index.php">
            <img src="images/white-logo.svg" alt="logo" width="130" class="img-fluid">
          </a>
        </h5>
      </div>
      <div class="col-lg-2 col-md-4">
        <h5>Quick Links</h5>
        <ul class="footer-links">
          <li>
            <a href="services.php">Our Services</a>
          </li>
          <li>
            <a href="about.php">About Us</a>
          </li>
          <li>
            <a href="#">Testimonials</a>
          </li>
          <li>
            <a href="#">Career</a>
          </li>
          <li>
            <a href="#">Blog</a>
          </li>
          <li>
            <a href="#">FAQs</a>
          </li>
        </ul>
      </div>
      <div class="col-lg-2 col-md-4">
        <h5>Services</h5>
        <ul class="footer-links">
          <li>
            <a href="androidappdevelopment.php">Android App Development</a>
          </li>
          <li>
            <a href="mobileappdevelopment.php">Mobile App Development</a>
          </li>
          <li>
            <a href="webappdevelopment.php">Web Development</a>
          </li>
          <li>
            <a href="#">MVP Development</a>
          </li>
          <li>
            <a href="#">Entreprise Solutions</a>
          </li>
          <li>
            <a href="#">Extended Teams</a>
          </li>
        </ul>
      </div>
      <div class="col-lg-2 col-md-4">
        <h5>Solutions</h5>
        <ul class="footer-links">
          <li>
            <a href="#">Food Delivery App</a>
          </li>
          <li>
            <a href="#">Grocery Delivery App</a>
          </li>
          <li>
            <a href="#">Photo Editing App</a>
          </li>
          <li>
            <a href="#">Video Editing App</a>
          </li>
          <li>
            <a href="#">Dating App</a>
          </li>
        </ul>
      </div>
      <div class="col-lg-2 col-md-4">
        <h5>Hire Developers</h5>
        <ul class="footer-links">
          <li>
            <a href="#">Hire iOS Developer</a>
          </li>
          <li>
            <a href="#">Hire Android Developer</a>
          </li>
          <li>
            <a href="#">Hire Flutter Developer</a>
          </li>
          <li>
            <a href="#">Hire Laravel Developer</a>
          </li>
          <li>
            <a href="#">Hire React Developer</a>
          </li>
        </ul>
      </div>
      <div class="col-lg-2 col-md-4">
        <h5>Case Study</h5>
        <ul class="footer-links">
          <li>
            <a href="#">Hire iOS Developer</a>
          </li>
          <li>
            <a href="#">Hire Android Developer</a>
          </li>
          <li>
            <a href="#">Hire Flutter Developer</a>
          </li>
          <li>
            <a href="#">Hire Laravel Developer</a>
          </li>
          <li>
            <a href="#">Hire React Developer</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</footer>
<section class="footer-bottom">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-6 sm-mb-2 text-md-start text-sm-center text-center">
        <span>© 2023 wayssofttech.com</span>
      </div>
      <div class="col-lg-6 col-md-6 text-md-end text-sm-center text-center">
        <a href="#" class="me-5">Privacy Policy</a>
        <a href="#">Terms & Conditions</a>
      </div>
    </div>
  </div>
</section>
<div class="overlay"></div>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/slick.js"></script>
<script src="js/aos.js"></script>
<script src="js/script.js"></script>
</body></html>