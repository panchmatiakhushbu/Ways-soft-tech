<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Contact us | Ways Soft-Tech</title>
    <meta name="description" content="Looking for a dependable Technology company for your project? We are happy to help you. Contact us to estimate your project!">
  </head>
  <body> <?php 
include "common/header.php"; 
?> <main>
      <!-- Banner section start -->
      <section class="top-banner banner-img contact-banner">
        <div class="container">
          <div class="text-details">
            <h1>Looking for a Dependable Technology Company for Your Project? We are Happy to Help You!</h1>
            <p class="has-large">It starts right here! Let’s talk about your project. After that, we will offer you an estimate to help you start the project quicker!</p>
            <a href="#contactus" class="custom-btn">Let's Talk</a>
          </div>
        </div>
      </section>
      <!-- Banner section end -->
      <section class="pad-80">
        <div class="container">
          <blockquote> We have been working with Ways Soft-Tech for more than two years. They have played a significant part in building different platforms. They have some of the finest developers we have worked with, and we have enjoyed dealing with them. Thanks a lot for everything. <span>- Brandon Ferguson, Chicago, USA</span>
          </blockquote>
        </div>
      </section>
      <section class="pb-80">
        <div class="container">
          <h2 data-aos="fade-up">What To Do Next?</h2>
          <p class="large" data-aos="fade-up">You have come one step closer to develop your digital products!</p>
          <div class="row mt-5">
            <div class="col-lg-4 col-md-6" data-aos="fade-up">
              <div class="process-details">
                <img src="images/consulting.png" alt="Consulting" class="img-fluid">
                <h6>Consulting</h6>
                <p>We discuss with you about the architecture, tech stack, timeline, and budget your project using a free consultation.</p>
              </div>
            </div>
            <div class="col-lg-4 col-md-6" data-aos="fade-up">
              <div class="process-details">
                <img src="images/connecting.png" alt="Connecting" class="img-fluid">
                <h6>Connecting</h6>
                <p>Our technology team will connect and walk you using a tech stack utilized to change your vision into a wonderful product.</p>
              </div>
            </div>
            <div class="col-lg-4 col-md-6" data-aos="fade-up">
              <div class="process-details">
                <img src="images/onboarding.png" alt="Onboarding" class="img-fluid">
                <h6>Onboarding</h6>
                <p>After signing up, our team would be onboard to jumpstart your project and deliver that with the optimum quality.</p>
              </div>
            </div>
          </div>
        </div>
      </section> <?php 
include "common/contact-us.php"; 
?>
    </main> <?php 
include "common/footer.php"; 
?>