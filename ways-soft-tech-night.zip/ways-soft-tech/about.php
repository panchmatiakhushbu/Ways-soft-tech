<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Ways Soft-Tech– Future-Ready Business Digital Transformation</title>
    <meta name="description" content="Future-Ready Business Digital Transformation! Our zealous Product Development Experts make industry-leading digital solutions globally.">
  </head>
  <body> <?php 
include "common/header.php"; 
?> <main>
      <!-- Banner section start -->
      <section class="top-banner banner-img about-banner">
        <div class="container">
          <div class="text-details">
            <h1>We Transform Your Businesses With Innovations!</h1>
            <p class="has-large">A Passionate Team, Which Makes The Technology Works in the Best Way for Your Business</p>
            <p>We are as excited as you to provide tech-enabled solutions to help grow your business and change your world! We have transformed so many companies around the world!</p>
            <a href="#contactus" class="custom-btn">Let's Talk</a>
          </div>
        </div>
      </section>
      <!-- Banner section end -->
      <section class="pad-80 count-sec">
        <div class="container">
          <div>
            <h2 data-aos="fade-up">Our Purpose</h2>
            <p class="large" data-aos="fade-up">To maximize the productivity of individuals & enterprises through our superior solutions and improve their quality of life.</p>
          </div>
        </div>
      </section>
      <section class="core-values">
        <div class="container">
          <div class="core-info">
            <h2>Our Core Values</h2>
            <p class="large">We're keen learners and veteran creators. Together, we create solutions that serve technologies and the humans behind them!</p>
            <ul>
              <li>Service Excellence</li>
              <li>Quality as Promised</li>
              <li>Constant Enhancement</li>
              <li>Strong Work Ethics </li>
            </ul>
          </div>
        </div>
      </section>
      <section class="pad-80 Our-vision common-sec">
        <div class="container">
          <h2 data-aos="fade-up">Our Vision</h2>
          <p class="large" data-aos="fade-up">To become a technology partner for entrepreneurs to help them unleash the potential of new ideas and progressively outline the future we live in!</p>
          <div class="row d-flex align-items-center mt-5">
            <div class="col-md-6" data-aos="fade-right">
              <h3>BHAG [Big Hairy Audacious Goal]</h3>
              <p>To build a trusted brand globally with a diversified group of companies having a value of $1 Billion!</p>
              <h3>Vivid Description</h3>
              <ul class="listing">
                <li>By 2035, Ways Soft-Tech will be the most admired brand globally & our customers will be proud for choosing us as their technology partner!</li>
                <li>Ways Soft-Tech will attract the best logical people & provide them with an environment to be creative thinkers & doers!</li>
                <li>Ways Soft-Tech will have a team of enthusiastic, loyal & professional team members, and they will feel very proud of their company and will be working in the group with a uniting spirit!</li>
                <li>By 2035, Ways Soft-Tech will consistently deliver products that make a valuable contribution and improve our customers' lives!</li>
                <li>Ways Soft-Tech has a headquarter based at Rajkot, Gujarat, and will spread in 5000+ Sq. Yard with facilities like indoor games, a gym, a meditation room, a restaurant, a relaxation area, gardens, and much more.</li>
              </ul>
            </div>
            <div class="col-md-6" data-aos="fade-left">
              <img src="images/our-vision.jpg" alt="our-vision" class="img-fluid">
            </div>
          </div>
        </div>
      </section>
      <section class="pb-80 count-sec">
        <div class="container">
          <div>
            <h2 data-aos="fade-up">Our Mission</h2>
            <p class="large" data-aos="fade-up">To make enterprise-grade product development accessible for entrepreneurs and help them reach a more extensive scale with agility!</p>
          </div>
        </div>
        <div class="counter-sec">
          <div class="container">
            <div id="projectFacts" class="sectionClass">
              <div class="projectFactsWrap">
                <div class="item" data-number="100" style="visibility: visible;">
                  <div class="d-flex count-info">
                    <p id="number1" class="number">100</p>
                    <span>+</span>
                  </div>
                  <p>Products Innovated</p>
                </div>
                <div class="item" data-number="95" style="visibility: visible;">
                  <div class="d-flex count-info">
                    <p id="number2" class="number">95</p>
                    <span>%</span>
                  </div>
                  <p>Happy Clients</p>
                </div>
                <div class="item" data-number="5" style="visibility: visible;">
                  <div class="d-flex count-info">
                    <p id="number3" class="number">5</p>
                    <span>+</span>
                  </div>
                  <p>Years in the Business</p>
                </div>
                <div class="item" data-number="3" style="visibility: visible;">
                  <div class="d-flex count-info">
                    <p id="number4" class="number">3</p>
                    <span>+</span>
                  </div>
                  <p>Work Locations</p>
                </div>
                <div class="item" data-number="50" style="visibility: visible;">
                  <div class="d-flex count-info">
                    <p id="number5" class="number">50</p>
                    <span>+</span>
                  </div>
                  <p>Digital Creators</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section> <?php 
include "common/testimonial-slider.php"; 
?> <?php 
include "common/contact-us.php"; 
?>
    </main> <?php 
include "common/footer.php"; 
?>