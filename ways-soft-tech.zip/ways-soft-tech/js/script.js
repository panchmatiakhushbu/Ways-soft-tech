/*Header js satrt*/

const overlay = document.querySelector(".overlay");
const body = document.querySelector("body");
const menuBtn = document.querySelector(".menu-btn");
const menuItems = document.querySelector(".menu-items");
const expandBtn = document.querySelectorAll(".expand-btn");

function toggle() {
    // disable overflow body
    body.classList.toggle("overflow");
    // dark background
    overlay.classList.toggle("overlay--active");
    // add open class
    menuBtn.classList.toggle("open");
    menuItems.classList.toggle("open");
}

menuBtn.addEventListener("click", e => {
    e.stopPropagation();
    toggle();
})

window.onkeydown = function( event ) {
    const key = event.key; // const {key} = event; in ES6+
    const active = menuItems.classList.contains('open');
    if (key === "Escape" && active) {
        toggle();
    }
};

document.addEventListener('click', e => {
    let target = e.target,
        its_menu = target === menuItems || menuItems.contains(target),
        its_hamburger = target === menuBtn,
        menu_is_active = menuItems.classList.contains('open');
    if (!its_menu && !its_hamburger && menu_is_active) {
        toggle();
    }
});

// mobile menu expand
expandBtn.forEach((btn) => {
    btn.addEventListener("click", () => {
        btn.classList.toggle("open");
    });
});

/*Header js end */



/*On scroll header fixed js start*/

$(window).scroll(function() {
if ($(this).scrollTop() > 1){  
    $('header').addClass("fixed");
  }
  else{
    $('header').removeClass("fixed");
  }
});

/*On scroll header fixed js end*/4
/*top slider js start*/
$(()=>{
  var createSlick = ()=>{
    let slider = $(".slider");

    slider.not('.slick-initialized').slick({
      speed: 500,
	  autoplaySpeed: 3000,
	  autoplay: true,
	  fade: true,
	  arrows: true,
	  cssEase: 'linear',
	  infinite: true,
      dots: false,
      slidesToShow: 1,
      slidesToScroll: 1     
    });	
  }

  createSlick();

 $(window).on( 'resize orientationchange', createSlick );
})

/* top slider js end */

/*counter section js start*/


	$.fn.jQuerySimpleCounter = function( options ) {
	    var settings = $.extend({
	        start:  0,
	        end:    100,
	        easing: 'swing',
	        duration: 400,
	        complete: ''
	    }, options );

	    var thisElement = $(this);

	    $({count: settings.start}).animate({count: settings.end}, {
			duration: settings.duration,
			easing: settings.easing,
			step: function() {
				var mathCount = Math.ceil(this.count);
				thisElement.text(mathCount);
			},
			complete: settings.complete
		});
	};


$('#number1').jQuerySimpleCounter({end: 100,duration: 3000});
$('#number2').jQuerySimpleCounter({end: 95,duration: 3000});
$('#number3').jQuerySimpleCounter({end: 5,duration: 2000});
$('#number4').jQuerySimpleCounter({end: 3,duration: 2500});
$('#number5').jQuerySimpleCounter({end: 50,duration: 2500});



  	/* AUTHOR LINK */
     $('.about-me-img').hover(function(){
            $('.authorWindowWrapper').stop().fadeIn('fast').find('p').addClass('trans');
        }, function(){
            $('.authorWindowWrapper').stop().fadeOut('fast').find('p').removeClass('trans');
        });
  

/*counter section js end*/

/*testnomial js start*/

$('.testimonial_owlCarousel').owlCarousel({
    loop:true,
    margin:10,
    dots:false,
    nav:true,
    autoplay:true,   
    smartSpeed: 3000, 
    autoplayTimeout:4000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});

/*testnomial js end*/

/*scroll link js start*/

$(document).ready(function(){
	$('a[href^="#"]').on('click',function (e) {
	    e.preventDefault();
	    var target = this.hash;
	    var $target = $(target);
	    $('html, body').stop().animate({
	        'scrollTop': $target.offset().top
	    }, 900, 'swing', function () {	        
	    });
	});
});

/*scroll link js end*/

/*Aos animation js start*/
AOS.init({
  duration: 1200,
})
/*Aos animation js end*/

/*developement service slider js start*/
$('.development-service').slick({
  dots: false,
  infinite: true,
  speed: 300,
  slidesToShow: 2,
  slidesToScroll: 1,
  autoplay:true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        infinite: true,
        dots: false
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }    
  ]
});
/*developement service slider js end*/